package project1.maven;

public interface Chocolates {
	public int weight_of_chocolates(int no_chocolates,int weight);

}
