package project1.maven;
 class Sweets 
 {

	public int sweets_total_weight(int no_of_sweets,int weight_of_sweets) {
		int total_weight=0;
		total_weight=no_of_sweets*weight_of_sweets;
		return total_weight;
		// TODO Auto-generated constructor stub
	}

}
